import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _98f7d340 = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _0cb36595 = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _ec1cd51a = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _a5ee559a = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _f55c3c4e = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))
const _0cb1dec0 = () => interopDefault(import('..\\pages\\edit' /* webpackChunkName: "" */))
const _d859cf00 = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _98f7d340,
    children: [{
      path: "",
      component: _0cb36595,
      name: "home"
    }, {
      path: "/login",
      component: _ec1cd51a,
      name: "login"
    }, {
      path: "/register",
      component: _ec1cd51a,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _a5ee559a,
      name: "profile"
    }, {
      path: "/settings",
      component: _f55c3c4e,
      name: "settings"
    }, {
      path: "/edit",
      component: _0cb1dec0,
      name: "edit"
    }, {
      path: "/article/:slug",
      component: _d859cf00,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
